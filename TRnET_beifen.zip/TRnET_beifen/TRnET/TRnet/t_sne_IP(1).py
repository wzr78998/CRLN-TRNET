import random

from sklearn import manifold
import numpy as np
import scipy.io as sio
from sklearn.decomposition import PCA
from utils_HSI import open_file
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def select_top_half_mean_similar_features_and_labels(features, labels):
    unique_labels = np.unique(labels)
    top_half_similar_features = []
    top_half_similar_labels = []

    for label in unique_labels:
        # 获取同类特征向量
        same_class_features = features[labels == label]
        same_class_labels = labels[labels == label]
        # if same_class_features.shape[0]>1500:
        #     same_class_features=same_class_features[:1500]
        #     same_class_labels=same_class_labels[:1500]


        # 计算特征均值
        mean_feature = np.mean(same_class_features, axis=0).reshape(1, -1)

        # 计算均值与特征向量的相似度
        similarity_vector = cosine_similarity(mean_feature, same_class_features).flatten()

        # 按相似度排序
        sorted_indices = np.argsort(similarity_vector)[::-1]

        # 获取前50%的特征向量
        selected_indices = sorted_indices[:int(len(sorted_indices))]

        # 存储筛选后的特征向量和标签
        top_half_similar_features.append(same_class_features[selected_indices])
        top_half_similar_labels.append(same_class_labels[selected_indices])

    return np.vstack(top_half_similar_features), np.hstack(top_half_similar_labels)

def normalize(nparray, order=2, axis=0):
    """Normalize a N-D numpy array along the specified axis."""
    nparray = np.array(nparray)
    norm = np.linalg.norm(nparray, ord=order, axis=axis, keepdims=True)
    return nparray / (norm + np.finfo(np.float32).eps)
def applyPCAt(X, numComponents=75):
    newX = np.reshape(X, (-1, X.shape[1])) ##沿光谱维度展平
    pca = PCA(n_components=numComponents, whiten=False)
    newX = pca.fit_transform(newX)
    newX = np.reshape(newX, (X.shape[0],numComponents))
    return newX, pca
model_list=[38]
# model_list=[9,13,14,21,25]
# model_list=[7,8]
for models in model_list:
    if models == 38:
        models = 'Houston18'
        DATA = sio.loadmat('./data/Houston/Houston18.mat')['ori_data']
        # DATA = np.asarray(open_file('./data/Houston/Houston18.mat')['ori_data']).transpose(1, 2, 0)
        # DATA = normalize(DATA)
        # G = np.asarray(open_file('./data/Houston/Houston18_7gt.mat')['map'])
        G=sio.loadmat('./data/Houston/Houston18_7gt.mat')['map']
        # 将第6类的标签置0
        G[G == 6] = 0
        # 将标签为7的改为6
        G[G == 7] = 6
        train_labels = G[np.where(G!=0)]-1

        train_features =DATA[np.where(G!=0)]


        path = './data/Houston/Houston18'
        data = 'Houston18'
    if models == 2:
        models = 'svm'
        train_features = np.load('./feature_IP_svm.npy')
        train_labels = np.load('./label_IP_svm.npy')
        path = './t_sne/IP/svm'
        data = 'IP'
    if models == '3':
        models = '3DCNN'
        train_features = np.load('./t_sne/IP_data/IP_3DCNN_feature.npy')
        train_labels = np.load('./t_sne/IP_data/IP_3DCNN_label.npy')
        path = './t_sne/IP/3DCNN'
        data = 'IP'
    if models == 4:
        models = 'graphsage'
        train_features = np.load('./t_sne/IP_data/IP_graphsage_feature.npy')
        train_labels = np.load('./t_sne/IP_data/IP_graphsage_label.npy')
        path = './t_sne/IP/graphsage'
        data = 'IP'
    if models == 5:
        models = 'meta_graphsage'
        train_features = np.load('./t_sne/IP_data/IP_meta_graphsage_feature.npy')
        train_labels = np.load('./t_sne/IP_data/IP_meta_graphsage_label.npy')
        path = './t_sne/IP/meta_graphsage'
        data = 'IP'
    if models == 6:
        models = 'meta_SP'
        train_features = np.load('./t_sne/IP_data/IP_meta_SP_feature.npy')
        train_labels = np.load('./t_sne/IP_data/IP_meta_SP_label.npy')
        path = './t_sne/IP/meta_SP'
        data = 'IP'
    if models == 7:
        models = 'OUR'
        train_features = np.load('./t_sne/IP_data/IP_OUR_feature.npy')
        train_labels = np.load('./t_sne/IP_data/IP_OUR_labels.npy')
        path = './t_sne/IP/OUR'
        data = 'IP'
    if models == 8:
        models = 'DCFSL_IP'
        train_features = np.load('./t_sne/IP_data/DCFSL_IP-feature.npy')
        train_labels = np.load('./t_sne/IP_data/DCFSL_IP-labels.npy')
        path = './t_sne/IP/DCFSL'
        data = 'IP'
    if models == 9:
        models = 'OUR_SA'
        train_features = np.load('./t_sne/SA_data/OUR_SA-feature.npy')
        train_features=normalize(train_features)
        train_labels = np.load('./t_sne/SA_data/OUR_SA-labels.npy')
        path = './t_sne/SA/OUR_SA'
        data = 'SA'

    if models == 10:
        models = 'svm_SA'
        train_features = np.load('./t_sne/SA_data/feature_SA_svm.npy')
        train_labels = np.load('./t_sne/SA_data/label_SA_svm.npy')
        path = './t_sne/SA/svm'
        data = 'SA'

    if models == 11:
        models = '3DCNN_SA'
        train_features = np.load('./t_sne/SA_data/3DCNN_feature.npy')
        train_labels = np.load('./t_sne/SA_data/3DCNN_label.npy')
        path = './t_sne/SA/3DCNN'
        data = 'SA'

    if models == 12:
        models = 'graphsage_SA'
        train_features = np.load('./t_sne/SA_data/feature_graphsage.npy')
        train_labels = np.load('./t_sne/SA_data/label_graphsage.npy')
        path = './t_sne/SA/graphsage'
        data = 'SA'

    if models == 13:
        models = 'meta_SP_SA'
        train_features = np.load('./t_sne/SA_data/feature_meta_SP.npy')
        train_labels = np.load('./t_sne/SA_data/label_meta_SP.npy')
        path = './t_sne/SA/meta_SP'
        data = 'SA'

    if models == 14:
        models = 'DCFSL_SA'
        train_labels = np.load('./t_sne/SA_data/DCFSL_SA-labels.npy')
        train_features = np.load('./t_sne/SA_data/DCFSL_SA-feature.npy')[:train_labels.shape[0], :]
        path = './t_sne/SA/DCFSL'
        data = 'SA'

    if models == 15:
        models = 'meta_graphsage_SA'
        train_features = np.load('./t_sne/SA_data/feature_meta_graphsage.npy')
        train_labels = np.load('./t_sne/SA_data/label_meta_graphsage.npy')
        path = './t_sne/SA/meta_graphsage'
        data = 'SA'
    if models == 16:
        models = 'svm_UP'
        train_features = np.load('./t_sne/UP_data/feature_UP_svm.npy')
        train_labels = np.load('./t_sne/UP_data/label_UP_svm.npy')
        path = './t_sne/UP/svm'
        data = 'UP'
    if models == 17:
        models = 'CDAN_UP'
        train_labels = np.load('./t_sne/UP_data/CDAN_predict.npy')
        train_features = np.load('./t_sne/UP_data/CDAN_test_feature.npy').reshape(train_labels.shape[0], -1)
        path = './t_sne/UP/CDAN'
        data = 'UP'
    if models == 18:
        models = '3DCNN_UP'

        train_labels = np.load('./t_sne/UP_data/predict_dan.npy')
        train_features = np.load('./t_sne/UP_data/test_features_dan.npy').reshape(train_labels.shape[0], -1)
        path = './t_sne/UP/3DCNN'
        data = 'UP'

    if models == 19:
        models = 'graphsage_UP'
        train_features = np.load('./t_sne/UP_data/feature_graphsage.npy')
        train_labels = np.load('./t_sne/UP_data/label_graphsage.npy')
        path = './t_sne/UP/graphsage'
        data = 'UP'
    if models == 20:
        models = 'meta_graphsage_UP'
        train_features = np.load('./t_sne/UP_data/feature_meta_graphsage.npy')[:42700, :]
        train_labels = np.load('./t_sne/UP_data/label_meta_graphsage.npy')
        path = './t_sne/UP/meta_graphsage'
        data = 'UP'
    if models == 21:
        models = 'meta_SP_UP'
        train_features = np.load('./t_sne/UP_data/feature_meta_SP.npy')
        train_labels = np.load('./t_sne/UP_data/label_meta_SP.npy')
        path = './t_sne/UP/meta_SP'
        data = 'UP'
    if models == 22:
        models = 'DFSL_UP'
        train_labels = np.load('./t_sne/UP_data/DFSLNN_predict.npy')
        train_features = np.load('./t_sne/UP_data/DFSL_UP_test_feature.npy').reshape(train_labels.shape[0], -1)
        path = './t_sne/UP/DFSL'
        data = 'UP'
    if models == 23:
        models = 'OUR_UP'
        train_features = np.load('./up_features.npy').reshape(42731, -1)
        # train_features,_=applyPCAt(train_features,20)

        #train_features = normalize(train_features)
        train_labels = np.load('./up_predict.npy')
        path = './t_sne/UP/OUR_UP'
        data = 'UP'
    if models == 24:
        models = 'orig_UP'

        DATA = sio.loadmat('data/paviaU/paviaU.mat')['paviaU']
        DATA = normalize(DATA)
        G = sio.loadmat('data/paviaU/paviaU_gt.mat')['paviaU_gt']
        train_labels = G[np.where(G != 0)] - 1

        train_features = DATA[np.where(G != 0)]


        path = './TSNE/PU/orig'
        data = 'UP'
    if models == 25:
        models = 'orig_SA'
        DATA = sio.loadmat('data/salinas/salinas_corrected.mat')['salinas_corrected']
        DATA = normalize(DATA)
        G = sio.loadmat('data/salinas/salinas_gt.mat')['salinas_gt']
        train_labels = G[np.where(G != 0)] - 1

        train_features = DATA[np.where(G != 0)]
        path = './TSNE/SA/orig'
        data = 'SA'
    if models == 26:
        models = 'DCFSL_UP'
        train_features = np.load('./t_sne/UP_data/DCFSL_UP_feature.npy')
        train_labels = np.load('./t_sne/UP_data/DCFSL_UP_label.npy')
        path = './t_sne/UP/DCFSL_UP'
        data = 'UP'
    if models == 27:
        models = 'DFSL_IP'
        train_features = np.load('./t_sne/IP_data/feature_SSGCN.npy')
        train_labels = np.load('./t_sne/IP_data/label_SSGCN.npy')
        path = './t_sne/UP/DFSL_IP'
        data = 'IP'
    if models == 28:
        models = 'MCFSL_IP'
        train_features = np.load('./tsne_data/IP/feature_71.30494640574294.npy')
        train_labels = np.load('./tsne_data/IP/label_71.30494640574294.npy')
        path = './TSNE/IP/MCFSL_IP'
        data = 'IP'
    if models == 29:
        models = 'MCFSL_PU'
        train_features = np.load('./tsne_data/PU/feature_88.39952259483748.npy')
        train_labels = np.load('./tsne_data/PU/label_88.39952259483748.npy')
        path = './TSNE/PU/MCFSL_PU'
        data = 'UP'
    if models == 30:
        models = 'MCFSL_SA'
        train_features = np.load('./tsne_data/SA/feature_91.87589039575201.npy')
        train_labels = np.load('./tsne_data/SA/label_91.87589039575201.npy')
        path = './TSNE/SA/MCFSL_SA'
        data = 'SA'
    if models == 31:
        models = 'RL_HS'
        train_features = np.load('./tsne_data/HS/feature_94.99264654387562.npy')
        train_labels = np.load('./tsne_data/HS/label_94.99264654387562.npy')
        path = './TSNE/HS/RL_HS'
        data = 'HS'
    if models == 32:
        models = 'JJ_Tre'
        train_features = np.load('./tsne_data/Tre/feature_98.60538934287837.npy')
        train_labels = np.load('./tsne_data/Tre/label_98.60538934287837.npy')
        path = './TSNE/Tre/JJ_tre'
        data = 'Tre'
    if models == 33:
        models = 'JJJ_Tre'
        train_features = np.load('./tsne_data/Tre/feature_98.5175930303235.npy')
        train_labels = np.load('./tsne_data/Tre/label_98.5175930303235.npy')
        path = './TSNE/Tre/JJJ_tre'
        data = 'Tre'
    if models == 34:
        models = 'base_B'
        train_features = np.load('./tsne_data/Tre/feature_90.97494517179504.npy')
        train_labels = np.load('./tsne_data/Tre/label_90.97494517179504.npy')
        path = './TSNE/Tre/base_B'
        data = 'Tre'
    if models == 35:
        models = 'MEDFN'
        train_features = np.load('./tsne_data/Tre/feature_98.50070912406294.npy')
        train_labels = np.load('./tsne_data/Tre/label_98.50070912406294.npy')
        path = './TSNE/Tre/MEDFN'
        data = 'Tre'
    if models == 36:
        models = 'D1'
        train_features = np.load('./tsne_data/Tre/feature_97.00272479564033.npy')
        train_labels = np.load('./tsne_data/Tre/label_97.00272479564033.npy')
        path = './TSNE/Tre/D1'
        data = 'Tre'
    if models == 37:
        models = 'D2'
        train_features = np.load('./tsne_data/Tre/feature_97.3627338421017.npy')
        train_labels = np.load('./tsne_data/Tre/label_97.3627338421017.npy')
        path = './TSNE/Tre/D2'
        data = 'Tre'


    if models == 38:
        models = 'Houston18'
        train_features = np.load('/home/skj/qzz/TRnET/feature_0.7706903121884147.npy')
        train_labels = np.load('/home/skj/qzz/TRnET/pred_probs0.7706903121884147.npy')
        path = '/home/skj/qzz/TRnET/t-SNE/Houston18'
        data = 'Houston18'

    maxval = train_features.max()
    minval = train_features.min()
    train_features = (train_features - minval) / (maxval - minval)
    fit_num = 2000

    tsne = manifold.TSNE(n_components=2, init='pca', random_state=100, learning_rate='auto',perplexity=100)  # n_components=2降维为2维并且可视化
    top_half_similar_features ,  train_labels= select_top_half_mean_similar_features_and_labels(train_features,
                                                                                                     train_labels)

    X_tsne = tsne.fit_transform(top_half_similar_features)
    # X_tsne=np.load('./IP_svm_tsne.npy')
    # np.save('./IP_svm_tsne.npy',X_tsne)
    print('save-tsne_ok')

    import tsneutil

    tsneutil.plot(X_tsne, train_labels, path, data, colors=tsneutil.MOUSE_10X_COLORS)
    print(models)
    print('ok')


    # X_tsne=np.load('./IP_svm_tsne.npy')
    # np.save('./IP_svm_tsne.npy',X_tsne)
    print('save-tsne_ok')






