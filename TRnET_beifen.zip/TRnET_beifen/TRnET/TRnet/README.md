# Unknown-Aware Domain Adversarial Learning for Open-Set Domain Adaptation (UADAL) [NeurIPS 2022]

This is an official code implementation for the paper "Unknown-Aware Domain Adversarial Learning for Open-Set Domain Adaptation (UADAL)" in NeurIPS 2022.
