from os.path import abspath, dirname, join

import numpy as np
import scipy.sparse as sp
from matplotlib import pyplot as plt

FILE_DIR = dirname(abspath(__file__))
DATA_DIR = join(FILE_DIR, "data")

MOUSE_10X_COLORS = {
    0: "#FFFF00",
    1: "#1CE6FF",
    2: "#FF34FF",
    3: "#FF4A46",
    4: "#008941",
    5: "#006FA6",
    6: "#A30059",
    7: "#FF2F80",
    8: "#7A4900",
    9: "#0000A6",
    10: "#63FFAC",
    11: "#B79762",
    12: "#004D43",
    13: "#8FB0FF",
    14: "#997D87",
    15: "#5A0007",
    16: "#809693",
    17: "#FEFFE6",
    18: "#1B4400",
    19: "#4FC601",
    20: "#3B5DFF",
    21: "#4A3B53",
    22: "#FF00E5",
    23: "#61615A",
    24: "#BA0900",
    25: "#6B7900",
    26: "#00C2A0",
    27: "#FFAA92",
    28: "#FF90C9",
    29: "#B903AA",
    30: "#D16100",
    31: "#DDEFFF",
    32: "#000035",
    33: "#7B4F4B",
    34: "#A1C299",
    35: "#300018",
    36: "#0AA6D8",
    37: "#013349",
    38: "#00846F",
}


def plot(
        x,
        y,
        path,
        data,
        ax=None,
        title=None,
        draw_legend=True,
        draw_centers=False,
        draw_cluster_labels=False,
        colors=None,
        legend_kwargs=None,
        label_order=None,
        **kwargs
):
    import matplotlib.pyplot

    if ax is None:
        _, ax = matplotlib.pyplot.subplots(figsize=(7,7))


    if title is not None:
        ax.set_title(title)

    plot_params = {"alpha": kwargs.get("alpha", 1), "s": kwargs.get("s", 10)}

    # Create main plot
    if label_order is not None:
        assert all(np.isin(np.unique(y), label_order))
        classes = [l for l in label_order if l in np.unique(y)]
    else:
        classes = np.unique(y)
    if colors is None:
        default_colors = matplotlib.rcParams["axes.prop_cycle"]
        colors = {k: v["color"] for k, v in zip(classes, default_colors())}
    if data=='IP':
        name=np.array(['Alfalfa','Corn-notill','Corn-mintill','Corn','Grass-pasture','Grass-tree','Grass-pasture-mowed','Hay-windrowed','Oats',
                   'Soybean-notill','Soybean-mintill','Sobean-clean','Wheat','Woods','Buildings-Grass-Trees-Drives','Stone-Steel-Towers'])
    if data=='UP':
        name=np.array(['Asphalt','Meadows','Metal','Gravel','Trees','Shadow','BS','Bitumen','Bricks'])
    if data=='SA':
        name=np.array(['Brocoli_green_weeds 1','Brocoli_green_weeds 2','Fallow','Fallow_rough_plow','Fallow_smooth','Stubblc','Celery','Grapes_untrained','Soil_vinyard_develop','Corn_senesced_weeds',
                       'Lettuce_romaine_4wk','Lettuce_romaine_5wk','Lettuce_romaine_6wk','Lettuce_romaine_7wk','Vinyard_untrained','Vinyard_treils'])
    if data=='HS':
        name=np.array(['Healthy grass','Stressed grass','Synthetic grass','Trees','Soil','Water','Residential','Commercial','Road','Highway',
                       'Railway','Parking lot 1','Parking lot 2','Tennis court','Running track'])
    if data=='Tre':
        name=np.array([' Apple trees', ' Buildings', 'Ground', 'Woods', ' Vineyard', 'Roads'])

    # if data=='Houston18':
    #     name=np.array(["grass healthy", "grass stressed", "trees",
    #                     "water", "residential buildings",
    #                     "non-residential buildings", "road"])
    if data == 'Houston18':
        name = np.array(["grass healthy", "grass stressed", "trees",
                         "water", "residential buildings",
                         "unknown"])
    if data=='Houston13':
        name=np.array(["grass healthy", "grass stressed", "trees",
                        "water", "residential buildings",
                        "non-residential buildings", "road"])

    point_colors = list(map(colors.get, y))

    ax.scatter(x[:, 0], x[:, 1], c=point_colors, rasterized=True, **plot_params)

    # Plot mediods
    if draw_centers:
        centers = []
        for yi in classes:
            mask = yi == y
            centers.append(np.median(x[mask, :2], axis=0))
        centers = np.array(centers)

        center_colors = list(map(colors.get, classes))
        ax.scatter(
            centers[:, 0], centers[:, 1], c=center_colors, s=150, alpha=1, edgecolor="k"
        )

        # Draw mediod labels
        if draw_cluster_labels:
            for idx, label in enumerate(classes):
                ax.text(
                    centers[idx, 0],
                    centers[idx, 1] + 2.2,
                    label,
                    fontsize=kwargs.get("fontsize", 6),
                    horizontalalignment="center",
                )

    # Hide ticks and axis
    ax.axis("on")
   #    ax.set_xticks([-80, -60, -40, -20, 0, 20, 40, 60, 80, 100, 120, 140]), ax.set_yticks(
   # [-80, -60, -40, -20, 0, 20, 40, 60, 80, 100]),
    if draw_legend:
        legend_handles = [
            matplotlib.lines.Line2D(
                [],
                [],
                marker="8",
                color="w",
                markerfacecolor=colors[yi],
                ms=10,
                alpha=1,
                linewidth=0,
                label=name[int(yi)],
                markeredgecolor="w",
            )

            for yi in classes
        ]
        legend_kwargs_ = dict(loc='lower right', frameon=True,fontsize=7 )
        if legend_kwargs is not None:
            legend_kwargs_.update(legend_kwargs)
        ax.legend(handles=legend_handles, **legend_kwargs_)
        # plt.tight_layout()
        #plt.figure(figsize=(8, 6), dpi=300)
        matplotlib.pyplot.savefig(path + '.png',dpi=1000)
        # matplotlib.pyplot.savefig(path + '.eps',dpi=600)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)


        matplotlib.pyplot.show()




