import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np

# 超参数取值范围
beta = [1e+1, 1e+0, 1e-1, 1e-2, 1e-3]  # 注意：1e-0 等同于 1，可以直接写为 1e0

# 对应的分类精度
# accuracy = [33.64, 54.03, 78.71, 75.41, 74.73]
# accuracy = [27.56,75.74,77.44,78.08,77.32]
accuracy = [66.59,68.01,74.01,73.28,73.54]
# 绘制折线图
plt.figure(figsize=(10, 6))  # 设置图像大小
plt.plot(beta, accuracy, marker='o', linestyle='-', color='b')  # 绘制折线图

# 添加标题和标签
# plt.title("Impact of Hyperparameter α on HOS (%)", fontsize=14)  # 图表标题
plt.xlabel(r"$\alpha$", fontsize=12)  # x 轴标签
plt.ylabel("HOS (%)", fontsize=12)  # y 轴标签

# 设置 x 轴为对数刻度
plt.xscale("log")  # 将 x 轴设置为对数刻度

# 自定义 x 轴刻度标签格式
def custom_formatter(x, pos):
    exponent = int(np.log10(x))
    return f"1e{exponent:+d}"

plt.gca().xaxis.set_major_formatter(FuncFormatter(custom_formatter))

# 添加网格线
plt.grid(True, linestyle='--', alpha=0.7)

# 添加图例
plt.legend(fontsize=12)

# 保存图像
plt.savefig("accuracy_vs_alpha_logscale (PU).png", dpi=300, bbox_inches="tight")  # 保存为 PNG 格式

# 显示图像
plt.show()