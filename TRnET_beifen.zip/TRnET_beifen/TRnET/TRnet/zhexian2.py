import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

# 超参数取值范围
taul = [0.01, 0.03, 0.05, 0.07, 0.09]

# 对应的分类精度
# accuracy = [77.39, 77.80, 78.02, 78.72, 77.75]
accuracy = [76.17,74.56,76.47,77.44,75.43]
# accuracy = [71.05,72.52,72.15,74.01,71.92]
# 绘制折线图
plt.figure(figsize=(10, 6))  # 设置图像大小
plt.plot(taul, accuracy, marker='o', linestyle='-', color='b')  # 绘制折线图

# 添加标题和标签
# plt.title("Impact of Hyperparameter τ on HOS (%)", fontsize=14)  # 图表标题
plt.xlabel(r"$\tau$", fontsize=12)  # x 轴标签
plt.ylabel("HOS (%)", fontsize=12)  # y 轴标签

# 设置 x 轴刻度标签为具体的数值
plt.xticks(taul)  # 设置 x 轴刻度为具体的数值

# 设置 y 轴范围和刻度间隔
plt.ylim(50, 80)  # 设置 y 轴范围为 0 到 80
plt.gca().yaxis.set_major_locator(MultipleLocator(10))  # 设置 y 轴刻度间隔为 10

# 添加网格线
plt.grid(True, linestyle='--', alpha=0.7)

# 添加图例
plt.legend(fontsize=12)

# 保存图像
plt.savefig("accuracy_vs_tau_logscale (bot).png", dpi=300, bbox_inches="tight")  # 保存为 PNG 格式

# 显示图像
plt.show()