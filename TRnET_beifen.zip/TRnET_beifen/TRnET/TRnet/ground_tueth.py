import numpy as np
import matplotlib.pyplot as plt
from scipy import io
import imageio
import os
import spectral
import torch
import scipy.io as sio
def open_file(dataset):   #打开文件
    _, ext = os.path.splitext(dataset)   #函数将文件名拆分为基本名称和扩展名部分，并将结果存储在 _ 和 ext 变量中。
    ext = ext.lower()   #使用 ext.lower() 将扩展名部分转换为小写格式。
    if ext == '.mat':
        # Load Matlab array
        # matlab v5.0 files using "io.loadmat"
        # return io.loadmat(dataset)
        # Solve bug: NotImplementedError: Please use HDF reader for matlab v7.3 files, e.g. h5py
        import h5py
        return h5py.File(dataset)
    elif ext == '.tif' or ext == '.tiff':
        # Load TIFF file
        return imageio.imread(dataset)
    elif ext == '.hdr':
        img = spectral.open_image(dataset)
        return img.load()
    else:
        raise ValueError("Unknown file format: {}".format(ext))
def classification_map(map, groundTruth, dpi, savePath):

    fig = plt.figure(frameon=False)  # 创建一个新的图形窗口，不显示边框
    fig.set_size_inches(groundTruth.shape[1]*2.0/dpi, groundTruth.shape[0]*2.0/dpi) # 根据真实标签图像的尺寸和给定的dpi设置图形窗口的大小

    ax = plt.Axes(fig, [0., 0., 1., 1.])    # 创建一个新的坐标轴对象，设置位置和尺寸
    ax.set_axis_off()   # 关闭坐标轴的显示
    ax.xaxis.set_visible(False) # 设置x轴和y轴为不可见
    ax.yaxis.set_visible(False)
    fig.add_axes(ax)    # 将坐标轴对象添加到图形窗口中

    ax.imshow(map)  # 在坐标轴上显示分类映射图像
    fig.savefig(savePath, dpi = dpi)     # 将图形窗口保存为文件，根据给定的路径和dpi设置


def draw_map(best_G,  acc):
    # 初始化一个与best_G相同大小的三维数组hsi_pic，用于存储RGB图像数据
    hsi_pic = np.zeros((best_G.shape[0], best_G.shape[1], 3), dtype=np.uint8)
    for i in range(best_G.shape[0]):
        # 遍历best_G中的每一行
        for j in range(best_G.shape[1]):
            # 遍历best_G中的每一列
            if best_G[i][j] == 0.0:
                hsi_pic[i][j] = [0, 0, 0]  # 黑色
            if best_G[i][j] == 1.0:
                hsi_pic[i][j] = [255, 0, 0]  # 红
            if best_G[i][j] == 2.0:
                hsi_pic[i][j] = [210,105,30] # 橙
            if best_G[i][j] == 3.0:
                hsi_pic[i][j] = [255, 255, 0]  # 黄
            if best_G[i][j] == 4.0:
                hsi_pic[i][j] = [0, 128, 0]  # 绿
            if best_G[i][j] == 5.0:
                hsi_pic[i][j] = [0, 0, 255]  # 蓝
            if best_G[i][j] == 6.0:
                hsi_pic[i][j] = [0, 255, 255]  # 青
            if best_G[i][j] == 7.0:
                hsi_pic[i][j] = [128, 0, 128]  # 紫
            if best_G[i][j] == 8.0:
                hsi_pic[i][j] = [128, 0, 128] # 粉
            if best_G[i][j] == 9.0:
                hsi_pic[i][j] = [128, 0, 128] # 棕
            if best_G[i][j] == 10.0:
                hsi_pic[i][j] = [255, 255, 255]  # 白色

    # 调用classification_map函数，将hsi_pic图像和best_G矩阵作为参数传入，
    # 并设置DPI为100，保存为PNG格式的图像文件，文件名包含准确率acc
    # classification_map(hsi_pic, best_G, 100,
    #                    str('./map/' + 'map_'  + 'acc:' + str(acc) + '.png'))
    # 调用classification_map函数，同样传入hsi_pic图像和best_G矩阵，
    # 并设置DPI为100，保存为EPS格式的矢量图文件，文件名同样包含准确率acc
    classification_map(hsi_pic, best_G, 100,
                       str('/home/skj/qzz/CRLN/TRnET_beifen/TRnET/TRnet/data/Bot/'+ 'map_'  + 'acc:' + str(acc) + '.eps'))

if __name__=='__main__':
    gt = np.asarray(sio.loadmat('/home/skj/qzz/CRLN/TRnET_beifen/TRnET/TRnet/data/Bot/BOT6_gt.mat')['map'])
    # gt = io.loadmat('datasets/Houston/Houston13_7gt.mat')['map']
    gt = torch.from_numpy(gt).to('cuda')
    draw_map(gt, 0.99)