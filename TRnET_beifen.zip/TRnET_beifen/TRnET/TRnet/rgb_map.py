import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from scipy import io
from utils_HSI import open_file
import scipy.io as sio

def display_hyperspectral_image(hsi_image, rgb_bands):
    """
    Display a pseudocolor image from a hyperspectral image.

    Parameters:
    hsi_image : numpy.ndarray
        The 3D hyperspectral image data.
    rgb_bands : list
        A list of three integers representing the bands to use for the R, G, and B channels.
    """
    # Check if the number of bands is sufficient
    if len(rgb_bands) < 3:
        raise ValueError("Please provide three distinct bands for RGB channels.")

    # Extract the specified bands
    r_band = hsi_image[:, :, rgb_bands[0]]
    g_band = hsi_image[:, :, rgb_bands[1]]
    b_band = hsi_image[:, :, rgb_bands[2]]

    # Normalize the data to the range [0, 1]
    r_band = Normalize(vmin=r_band.min(), vmax=r_band.max())(r_band)
    g_band = Normalize(vmin=g_band.min(), vmax=g_band.max())(g_band)
    b_band = Normalize(vmin=b_band.min(), vmax=b_band.max())(b_band)

    # Create the pseudocolor image
    map = np.dstack((r_band, g_band, b_band))

    # Display the image
    # plt.imshow(pseudocolor_image)
    # plt.axis('off')  # Turn off axis numbers and ticks
    # plt.show()
    # fig.savefig(savePath, dpi=dpi)
    dpi = 100

    fig = plt.figure(frameon=False)  # 创建一个新的图形窗口，不显示边框
    fig.set_size_inches(hsi_image.shape[1]*2.0/dpi, hsi_image.shape[0]*2.0/dpi) # 根据真实标签图像的尺寸和给定的dpi设置图形窗口的大小

    ax = plt.Axes(fig, [0., 0., 1., 1.])    # 创建一个新的坐标轴对象，设置位置和尺寸
    ax.set_axis_off()   # 关闭坐标轴的显示
    ax.xaxis.set_visible(False) # 设置x轴和y轴为不可见
    ax.yaxis.set_visible(False)
    fig.add_axes(ax)    # 将坐标轴对象添加到图形窗口中

    ax.imshow(map)  # 在坐标轴上显示分类映射图像
    fig.savefig(str('/ssd/QZZ/TRnET/rgbmap/Houston18_rgbmap.png'), dpi = dpi)     # 将图形窗口保存为文件，根据给定的路径和dpi设置


# Example usage:
# Assuming `hsi_data` is your 3D hyperspectral image data loaded as a numpy array
# You need to replace `hsi_data` with your actual hyperspectral image data
# and choose the appropriate bands for your application.
# hsi_data = io.loadmat('datasets/Houston/Houston13.mat')['ori_data'] # Example data
hsi_data = np.asarray(sio.loadmat('/ssd/QZZ/TRnET/TRnet/data/Houston/Houston18.mat')['ori_data'])
# hsi_data=np.load('datasets/Houston/Houston13_df_image.npy')
rgb_bands = [13,20,33]  # Example band indices for R, G, and B
display_hyperspectral_image(hsi_data, rgb_bands)