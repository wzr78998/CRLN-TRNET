class SS_FE(nn.Module):
    def __init__(self, input_dim,output_dim,hidden_dim1,hidden_dim2,act,args):
        super().__init__()

        self.output_dim=output_dim

        self.spa_fe=FE_( input_dim=input_dim,output_dim=output_dim,hidden_dim=hidden_dim1,act=act)
        self.spe_fe = FE_(input_dim=args.patches**2, output_dim=output_dim, hidden_dim=hidden_dim2, act=act)
        self.fusin_layer=nn.Sequential(
            nn.Linear(self.output_dim*2,self.output_dim),

                                       act,

                                       nn.Linear(self.output_dim, self.output_dim),
                                       act,

                                       )



    def forward(self, x):
        patch=x.shape[2]
        x = x.permute(0, 2, 3, 1).reshape(x.shape[0], -1, x.shape[1])


        x1=x.reshape(-1,x.shape[-1])
        x2=x.reshape(-1,patch**2,x.shape[-1]).permute(0,2,1).reshape(-1,patch**2)

        x1=self.spa_fe(x1).reshape(-1,patch**2,self.output_dim )
        x2 = self.spe_fe(x2).reshape(-1,x.shape[-1] , self.output_dim)




        x=self.fusin_layer(torch.cat([torch.mean(x1,1),torch.mean(x2,1)],1))


        return x


    **************************************************************************************

    class FE_(nn.Module):
        def __init__(self, input_dim, output_dim, hidden_dim, act):
            super().__init__()

            self.input_dim = input_dim
            self.output_dim = output_dim
            self.hiddent_dim = hidden_dim
            self.act = act
            self.layer = nn.Sequential()
            if len(self.hiddent_dim) == 0:

                self.layer.append(nn.Linear(self.input_dim, output_dim))
                self.layer.append(self.act)
            else:
                for i in range(len(hidden_dim)):
                    if i == 0:
                        self.layer.append(nn.Linear(self.input_dim, self.hiddent_dim[0]))

                        self.layer.append(self.act)
                    if i != 0 and i != len(hidden_dim) - 1:
                        self.layer.append(nn.Linear(self.hiddent_dim[i - 1], self.hiddent_dim[i]))

                        self.layer.append(self.act)
                    if i == len(hidden_dim) - 1:
                        self.layer.append(nn.Linear(self.hiddent_dim[i - 1], self.output_dim))

                        self.layer.append(self.act)

        def forward(self, x):

            x = x.reshape(-1, self.input_dim)

            x = self.layer(x)

            return x
        ****************************************************************************************************************
        self.G = SS_FE(input_dim=48, output_dim=self.args.dim1, hidden_dim1=[self.args.dim2, self.args.dim3],
                       hidden_dim2=[self.args.dim5, self.args.dim6], act=nn.Tanh(), args=self.args)
        self.C = nn.Sequential(
            nn.Linear(in_features=self.args.dim1, out_features=self.args.dim8, bias=True),

            nn.SELU(),

            nn.Linear(in_features=self.args.dim8, out_features=self.all_num_class, bias=True))
        ***********************************************************************************************
        parser.add_argument('--dim1', type=int, default=260, help='4,5,6,7,8.')
        parser.add_argument('--back_num', type=int, default=1, help='4,5,6,7,8.')
        parser.add_argument('--dim2', type=int, default=36, help='4,5,6,7,8.')
        parser.add_argument('--dim3', type=int, default=352, help='4,5,6,7,8.')
        parser.add_argument('--dim4', type=int, default=140, help='4,5,6,7,8.')
        parser.add_argument('--dim5', type=int, default=140, help='4,5,6,7,8.')
        parser.add_argument('--dim6', type=int, default=239, help='4,5,6,7,8.')
        parser.add_argument('--dim7', type=int, default=79, help='4,5,6,7,8.')
        parser.add_argument('--dim8', type=int, default=459, help='4,5,6,7,8.')