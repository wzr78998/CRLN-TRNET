import matplotlib.pyplot as plt

# 数据
methods = ["SCLUDA", "MLUDA", "MSDA", "SSOUDA","UADAL","CRLN"]  # 方法名
# accuracy = [80.79,74.80,32.92,85.99,87.35,89.97]  # 算法精度
accuracy = [71.76,66.03,51.09,65.37,68.90,73.34]  # 算法精度
# 创建柱状图
# accuracy = [63.97,57.84,42.32,77.37,72.32,77.44]  # 算法精度
plt.bar(methods, accuracy, color='blue', width=0.6)

# 添加标题和标签
# plt.title("Algorithm Accuracy Comparison")
plt.xlabel("Methods")
plt.ylabel("HOS(%)")

# 显示刻度标签
plt.xticks(methods)

# 显示网格线
plt.grid(axis='y', linestyle='--', alpha=0.7)

# 保存图像
plt.savefig("K=2柱状图2.png", dpi=300, bbox_inches="tight")  # 保存为 PNG 格式

# 显示图像
plt.show()